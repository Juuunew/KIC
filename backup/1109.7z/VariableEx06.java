public class VariableEx06 {
    public static void main(String[] args) {
       // int i = 2.5;
       // System.out.println( i );

       float f = 2.5f;
       double d = 2.5;
       System.out.println( f );
       System.out.println( d );

       // 지수
       double d2 = 1.0e3;
       System.out.println( d2 );
    }
}