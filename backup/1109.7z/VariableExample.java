public class VariableExample {
    public static void main(String[] args) {
        int value = 10;
        int result = value + 10;
        System.out.println(result);
    }
}