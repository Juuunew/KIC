public class PyramidEx01 {
    public static void main(String[] args){
        for( char i=97; i<=104; i++) {
            for( char j=97; j<=i; j++)
            System.out.println(i);
        }        
    }
}