public class VariableEx04 {
    public static void main(String[] args) {
        // 문자열 = String 으로 처리
        // String = class 형태
        // 문자열은 항상 ""
        String str1 = "Hello \n Java";
        System.out.println( str1 );
        System.out.println( "문자열" );

        // Error
        //String str2 = 'Hello';
        //System.out.println( str2 );
        
        
    }
}