public class Ex1 {
    public static void main(String[] args) {
        System.out.println( "Hello Java" );
        System.out.println( "안녕 자바");

        System.out.println( "안녕 자바" );
        System.out.printf( "Hello Java" );

        System.out.printf( "%s %s %s", "안녕", "자바", "hello" );

    }
}