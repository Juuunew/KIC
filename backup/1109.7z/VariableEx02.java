public class VariableEx02 {
    public static void main(String[] args) {
        boolean bool1 = true;
        System.out.println( bool1 );

        // true, false 는 반드시 소문자로!
        boolean bool2 = True;
    }
}