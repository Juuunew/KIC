public class CastingEx02 {
    public static void main(String[] args) {
        int i = 97;
        System.out.println( i );
        System.out.println( (char)i );
    }
}