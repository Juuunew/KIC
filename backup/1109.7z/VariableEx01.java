public class VariableEx01 {
    public static void main(String[] args) {
        // 변수의 선언
        int intNum;
        // 변수의 초기화
        intNum = 0;
        // 변수값의 출력
        System.out.println( intNum );

        int intNum2 = 10;
        System.out.println( intNum2 );
    }
}

// Error : cannot find symbol = 변수명오타

