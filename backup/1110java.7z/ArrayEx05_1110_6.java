public class ArrayEx05_1110_6 {
    //public static void main(String[] args) 
    //public static void main(String args[]) 
    public static void main(String datas[]) {
        // 객체에 관련된 배열은 초기화 null
        String[] arr1 = new String[3];
        String[] arr2 = { "abc", "bcd", "cde" };

        System.out.println( arr1[0] );
        System.out.println( arr2[0] );
    }
}